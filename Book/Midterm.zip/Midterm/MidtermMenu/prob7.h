/* 
 * File:   main.cpp
 * Author: Tyler
 * Created on June 12 2019 
 * Purpose:  Array Structure Specification
 */

#ifndef PROB7_H
#define PROB7_H

//User Libraries
struct Prime{
	int prime;
	int power;
};
struct Primes{
	Prime *prime;
	int nPrimes;
};

#endif /* PROB7_H */
