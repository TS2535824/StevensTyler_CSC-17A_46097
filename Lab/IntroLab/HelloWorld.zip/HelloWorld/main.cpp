/*
 * File:   main.cpp
 * Author: Tyler Stevens
 * Created on June 17 2019
 * Purpose: Create a hello world program showing that Netbeans complies the code correctly.
 */

#include <iostream>

using namespace std;

int main() 
{
    cout<<"hello world!"<<endl;

    return 0;
}

